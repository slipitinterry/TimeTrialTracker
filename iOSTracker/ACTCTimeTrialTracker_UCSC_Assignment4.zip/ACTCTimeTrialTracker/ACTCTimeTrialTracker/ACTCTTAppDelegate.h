//
//  ACTCTTAppDelegate.h
//  ACTCTimeTrialTracker
//
//  Created by ridgway on 9/18/14.
//  Copyright (c) 2014 Ridgway Coders. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ACTCTTAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
