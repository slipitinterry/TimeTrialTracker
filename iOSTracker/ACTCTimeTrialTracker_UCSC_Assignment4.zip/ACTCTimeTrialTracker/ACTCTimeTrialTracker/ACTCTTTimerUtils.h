//
//  ACTCTTTimerUtils.h
//  ACTCTimeTrialTracker
//
//  Created by ridgway on 10/12/14.
//  Copyright (c) 2014 Ridgway Coders. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ACTCTTTimerUtils : NSObject

+ (NSString *) floatToTimeString:(float)time;

@end
