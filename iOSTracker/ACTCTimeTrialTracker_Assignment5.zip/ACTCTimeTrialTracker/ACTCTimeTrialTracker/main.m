//
//  main.m
//  ACTCTimeTrialTracker
//
//  Created by ridgway on 9/18/14.
//  Copyright (c) 2014 Ridgway Coders. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ACTCTTAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ACTCTTAppDelegate class]));
    }
}
